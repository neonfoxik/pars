from docxtpl import DocxTemplate
import openpyxl

wb = openpyxl.load_workbook(filename='name1.xlsx')
sheet = wb['Sheet1']

"""" yelow """
company = sheet['A1'].value
dictionary = sheet['B1'].value
quantity = sheet['C1'].value
data = sheet['D1'].value
time = sheet['Q1'].value
place = sheet['E1'].value
money = sheet['F1'].value
director_name = sheet['K1'].value
customer = sheet['G1'].value


"""" green """
spec_comp_name = sheet['I1'].value
spec = sheet['H1'].value
spec_company_director = sheet['J1'].value

doc = DocxTemplate("file.docx")

context = {
    'company': company,
    'dictionary': dictionary,
    'quantity': quantity,
    'time': time,
    'place': place,
    'money': money,
    'director_name': director_name,
    'customer': customer,
    'm_q': 170,
    'spec_company_director': spec_company_director,
    'spec_comp_name': spec_comp_name,
    'spec': spec
}

doc.render(context)

doc.save("save.docx")